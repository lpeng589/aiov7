--2017-12-14 18:49:09:�½���
    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSysSetting]') AND type in (N'U'))
    begin
    delete from tblLanguage where id in (select f.languageId from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblSysSetting') 
    delete from tblLanguage where id in (select f.groupName from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblSysSetting')
    delete from tblLanguage where id in (select t.languageId from tblDBTableInfo t where t.tableName = 'tblSysSetting') 
    exec proc_deleteExistsTable @tableName='tblSysSetting'
    drop table tblSysSetting
    end
create table tblSysSetting ( checkPersons varchar(8000) null,id varchar(30) not null, SCompanyID varchar(30) null,SysCode varchar(100) null,SysName varchar(100) null,DefaultValue varchar(100) null,Setting varchar(100) null,Remark varchar(1000) null,finishTime varchar(19) null,lastUpdateBy varchar(30) null,lastUpdateTime varchar(19) null,printCount int null,workFlowNode varchar(30) null,workFlowNodeName varchar(30) null,CheckPersont varchar(500) null,createBy varchar(30) not null,createTime varchar(19) null,statusId int null)
 alter   table   tblSysSetting add   constraint   PK_tblSysSetting  primary   key   (id)
insert into tblDBTableInfo (id,tableName,tableType,perantTableName,udType,updateAble,createBy,createTime,lastUpdateBy,lastUpdateTime,fieldCalculate,approveFlow,approveField,defRowCount,isSunCmpShare,isBaseInfo,needsCopy,wakeUp,hasNext,isView,isNull,reAudit,isLayout,layoutHTML,tableSysType,classFlag,classCount,draftFlag,extendButton,sysParameter,languageId,triggerExpress,tableDesc,MainModule,relationTable,relationView,isUsed,tWidth,tHeight,brotherType,copyParent)
values('71','tblSysSetting','0','','0','0','0','20081025174829','1','2009-03-31 16:58:53','<sql operation="add" id="tblSysSetting_Add"><sql operation="delete" post="before" id="tblSysSetting_Delete"><sql operation="update" post="before" id="tblSysSetting_Delete"><sql operation="update" id="tblSysSetting_Add">','0',null,'1','1','1','0','0','0','0','0','0','0',null,'Normal','0','0','0','','CommonFunction','DBTable144','1',null,'0',null,null,'1','0','0','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('a71m','71','checkPersons','0','0','0','0','0','0','','2','8000','0','100','100',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('928','71','id','1','0','1','0','0','0','','2','30','200','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('2f1ff2d7_0903101348429210025','71','SCompanyID','0','0','0','0','0','0','','2','30','200','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2662',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('919','71','SysCode','1','1','0','0','1','0','','2','100','200','0','0',null,null,'0','',null,'0','',null,null,'1',null,'DBField2663',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('920','71','SysName','1','2','0','0','0','0','','2','100','200','0','0',null,null,'0','',null,'0','',null,null,'1',null,'DBField2664',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('921','71','DefaultValue','1','3','0','0','0','0','','2','100','200','0','0',null,null,'0','',null,'0','',null,null,'1',null,'DBField2665',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('922','71','Setting','1','4','0','0','0','0','','2','100','200','0','0',null,null,'0','',null,'0','',null,null,'1',null,'DBField2666',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('7577861c_0903182150547500041','71','Remark','1','5','0','0','0','0','','3','1000','500','0','0',null,null,'0','',null,'0','',null,null,'1',null,'DBField2667',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('71','71','finishTime','0','100','0','0','0','0','','6','19','0','100','0','','','0','','','0','','','','1','','5fb96485_1207102228070150018','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('924','71','lastUpdateBy','0','100','0','0','0','0','','2','30','0','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2669',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('926','71','lastUpdateTime','0','100','0','0','0','0','','6','19','0','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2671',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1F617712E11C4B30A007CE36B09302','71','printCount','0','100','0','0','0','0','0','0','0','0','100','100',null,'','0','',null,'0','','',null,'1',null,'DBField2299',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('697AA61A-6E3C-4828-A331-164D2C','71','workFlowNode','0','100','0','0','0','0','','2','30','0','100','0','','','0','',null,'0','','',null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('22A6EC07-B501-4EFB-BDE1-D29122','71','workFlowNodeName','0','100','0','0','0','0','','2','30','0','100','0','','','0','',null,'0','','',null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('071','71','CheckPersont','0','100','0','0','0','0','','2','500','0','100','0','','','0','','','0','','','','1','','071','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('923','71','createBy','0','100','1','0','0','0','','2','30','0','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2668',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('925','71','createTime','0','100','0','0','0','0','','6','19','0','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2670',null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('927','71','statusId','0','100','0','0','0','0','0','0','0','0','100','100',null,null,'0','',null,'0','',null,null,'1',null,'DBField2672',null,null,'0','0')
insert into tblLanguage(zh_CN,id) values('ϵͳ��������','DBTable144')
insert into tblLanguage(zh_CN,id) values('��֧����','DBField2662')
insert into tblLanguage(zh_CN,id) values('ϵͳ�������','DBField2663')
insert into tblLanguage(zh_CN,id) values('��������','DBField2664')
insert into tblLanguage(zh_CN,id) values('Ĭ��ֵ','DBField2665')
insert into tblLanguage(zh_CN,id) values('����ֵ','DBField2666')
insert into tblLanguage(zh_CN,id) values('��ע','DBField2667')
insert into tblLanguage(zh_CN,id) values('���ʱ��','5fb96485_1207102228070150018')
insert into tblLanguage(zh_CN,id) values('����޸���','DBField2669')
insert into tblLanguage(zh_CN,id) values('�޸�ʱ��','DBField2671')
insert into tblLanguage(zh_CN,id) values('��ӡ����','DBField2299')
insert into tblLanguage(zh_CN,id) values('������','071')
insert into tblLanguage(zh_CN,id) values('������','DBField2668')
insert into tblLanguage(zh_CN,id) values('����ʱ��','DBField2670')
insert into tblLanguage(zh_CN,id) values('״̬','DBField2672')

 --2017-12-14 18:49:09:�½�ģ��

 delete from tblLanguage where id in (select modelName from tblModules where tblName='tblSysSetting')
 delete tblModelOperations where f_ref in (select id from tblModules where tblName='tblSysSetting')
 delete tblModules where  tblName='tblSysSetting'
 declare @newCode varchar(50),@retCode varchar(50),@parentCode varchar(50) set @parentCode ='' 
 exec proc_getNewClassCode 'tblModules',@parentCode,@retCode output,@newCode output 
 update tblModelOperations set moduleOpId=id where f_ref in (select id from tblModules where tblName='tblSysSetting') 
 --2017-12-14 18:49:09:�½�����

 delete tblReportsDet where f_ref in (select id from tblReports where reportNumber='tblSysSetting')
 delete from tblLanguage where id=(select ReportName from tblReports where reportNumber='tblSysSetting')
 delete from tblReports where  reportNumber='tblSysSetting'
INSERT INTO [tblReports]([createTime],[checkPersons],[newFlag],[moduleType],[printCount],[lastUpdateTime],[SCompanyID],[showCondition],[ReportName],[showHead],[lastUpdateBy],[mainModule],[createBy],[statusId],[id],[RowON],[SQLFileName],[ReportType],[ReportNumber],[showTotalStat],[CheckPersont],[finishTime],[defaultNoshow],[colTitleSort],[extendsBut],[crossColNum],[showRowNumber],[parentLinkReport],[showDet],[listType],[workFlowNodeName],[pageSize],[fixListTitle],[fixNumberCol],[workFlowNode],[auditPrint],[BillTable],[classCode],[ProcName],[showTotalPage],[endClassNumber]) values('2009-01-13 21:53:51','','OLD','','0','2009-01-13 21:53:51','00001','0','7354625c_0911141745415780164','1','4974bf46_0812092132365150434','0','4974bf46_0812092132365150434','0','739f3fd2_0901132153512030002','','tblSysSettingSQL.xml','TABLELIST','tblSysSetting','1','','2009-01-13 21:53:51','0','1','','0','1','','1','1','finish','0','0','0','-1','1','','','','0','')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('7354625c_0911141745415780164','ϵͳ���������б�')
 --2017-12-14 18:49:09:�½���ӡ����

 delete tblReportsDet where f_ref in (select id from tblReports where reportType='BILL' and billTable='tblSysSetting')
 delete from tblLanguage where id in(select ReportName from tblReports where reportType='BILL' and  billTable='tblSysSetting')
 delete from tblReports where reportType='BILL' and  billTable='tblSysSetting'
 --2017-12-14 18:49:09:�½�������

 delete from OAWorkFlowNodeApprover where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSysSetting')) 
 delete from OAWorkFlowNodeConditionDet where conditionId in (select id from OAWorkFlowNodeCondition  where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSysSetting'))) 
 delete from OAWorkFlowNodeCondition where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSysSetting')) 
 delete from OAWorkFlowNodeField where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSysSetting')) 
 delete from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSysSetting') 
 delete OAWorkFlowTemplate  where  templateFile='tblSysSetting'