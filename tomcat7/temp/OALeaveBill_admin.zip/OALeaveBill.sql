--2017-12-27 16:50:42:�½���
    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OALeaveBill]') AND type in (N'U'))
    begin
    delete from tblLanguage where id in (select f.languageId from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'OALeaveBill') 
    delete from tblLanguage where id in (select f.groupName from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'OALeaveBill')
    delete from tblLanguage where id in (select t.languageId from tblDBTableInfo t where t.tableName = 'OALeaveBill') 
    exec proc_deleteExistsTable @tableName='OALeaveBill'
    drop table OALeaveBill
    end
create table OALeaveBill ( checkPersons varchar(8000) null,classCode varchar(500) null,id varchar(30) not null, workFlowNode varchar(30) null,workFlowNodeName varchar(30) null,DepartmentCode varchar(200) null,EmployeeID varchar(200) null,duty varchar(80) null,LeavebillType varchar(200) null,due varchar(5000) null,STime varchar(19) null,LTime varchar(19) null,ATime varchar(200) null,BTime varchar(19) null,PFu varchar(80) null,BZhu varchar(5000) null,FJian varchar(1000) null,lastUpdateBy varchar(30) null,lastUpdateTime varchar(19) null,SCompanyID varchar(30) null,statusId int null,finishTime varchar(19) null,createBy varchar(30) not null,createTime varchar(19) null)
 alter   table   OALeaveBill add   constraint   PK_OALeaveBill  primary   key   (id)
insert into tblDBTableInfo (id,tableName,tableType,perantTableName,udType,updateAble,createBy,createTime,lastUpdateBy,lastUpdateTime,fieldCalculate,approveFlow,approveField,defRowCount,isSunCmpShare,isBaseInfo,needsCopy,wakeUp,hasNext,isView,isNull,reAudit,isLayout,layoutHTML,tableSysType,classFlag,classCount,draftFlag,extendButton,sysParameter,languageId,triggerExpress,tableDesc,MainModule,relationTable,relationView,isUsed,tWidth,tHeight,brotherType,copyParent)
values('44d1f2b3_1312131340081260049','OALeaveBill','0','','0','0','1','2013-12-13 13:40:08','1','2013-12-13 13:40:08','','','','1','0','0','0','0','0','0','0','0','1','<style>p{margin:0px}</style><table style="height:744px;width:889px;" bordercolor="#000000" align="center" border="1">
 <tbody>
 <tr>
 <td colspan="6">
 <h1 class="style1" align="center">
 <span style="font-size:32px;"><strong>��ٵ�</strong></span> 
 </h1>
 <p>
 ˵����
 </p>
 <p>
 1. ���̣�ְԱ &gt;&gt;&gt;&nbsp; ����&gt;&gt;&gt;���£�������ѡ��Ϊֱ���ϼ�����
 </p>
 <p>
 2. ���ٹ�˾����ְԱ�����ͨ����������ǰ1���ύ��ٵ���û�е����ߣ�һ�ɰ��������㡣�������ߣ�����������ȡ�ܾ�������������׼����
 </p>
 <p>
 3. �¼� 3 �������ߣ�����ǰ 2 ���ύ���룬��������󷽿��뿪��
 </p>
 <p>
 &nbsp; &nbsp;�¼� 5 �������ߣ�����ǰ 1 ���ύ���룬��������󷽿��뿪��
 </p>
 <p>
 4. ��٣�����ǰ 1 ���ύ���룬��������󷽿��뿪���������Ϊ���֤����ԭ���ո�ӡ�����޷��ṩ���֤�ߣ�����ͬ��׼�١�
 </p>
 <p>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���Ϊ3�죬��������������10�졣�����׼��������25���꣬Ů����23���ꡣ�Խ��Ǽ������Լ�����֤�������ں���.
 </p>
 <p>
 5. ���죺���ṩ���쵱�չҺ�СƱ���Լ������¼��ӡ�����޷��ṩ�߰��¼ټ��㡣
 </p>
 <p>
 6. ���٣����ṩ����ҽԺ�Һ�СƱ���Լ�ҽ������֤�����޷��ṩ�߰��¼ټ��㡣
 </p>
 <p>
 7. ���٣�����ǰ 15 ���ύ���룬��������󷽿��ݼ١�
 </p>
 <p>
 8. ���ݣ����ڱ�ע��ע������ʱ�䡣
 </p>
 <p>
 ����δ�����ˣ�����ѯ���²���
 </p>
 </td>
 </tr>
 <tr>
 <td height="40" width="96">
 <div align="center">
 ����
 </div>
 </td>
 <td width="176"><input type="text" title="����" inputtype="AIOText" fname="tblDepartment_DeptFullName" readonly="readonly"><br></td>
 <td width="73">
 <div align="center">
 ����
 </div>
 </td>
 <td><input type="text" title="����" inputtype="AIOText" fname="tblEmployee_EmpFullName" readonly="readonly"><br></td>
 <td width="86">
 <div align="center">
 ְ��
 </div>
 </td>
 <td width="235"><select title="ְ��" inputtype="AIOSelect" fname="duty"><option value="">ְ��</option><option></option></select><br></td>
 </tr>
 <tr>
 <td height="56" colspan="6">
 <p>
 ������
 </p>
 <p align="justify"><input type="radio" title="������" inputtype="AIORadio" fname="LeavebillType" value="������"><br></p>
 </td>
 </tr>
 <tr>
 <td height="111">
 <p align="center">
 ��ע
 </p>
 <p align="center">
 ��������ɣ�
 </p>
 </td>
 <td colspan="5"><textarea title="�������" inputtype="AIOTextarea" readonly="readonly" fname="due" style="width: 700px; height: 100px;"></textarea><br></td>
 </tr>
 <tr>
 <td height="42">
 <div align="center">
 ���ʱ��
 </div>
 </td>
 <td colspan="5">
 �� <input type="text" title="��ʼʱ��" inputtype="AIOText" fname="STime" readonly="readonly">&nbsp;�� <input type="text" title="����ʱ��" inputtype="AIOText" fname="LTime" readonly="readonly">&nbsp;�� <input type="text" title="��Сʱ" inputtype="AIOText" fname="ATime" readonly="readonly">&nbsp;Сʱ
 </td>
 </tr>
 <tr>
 <td height="37">
 <div align="center">
 ����
 </div>
 </td>
 <td colspan="2"><input type="radio" title="����" inputtype="AIORadio" fname="PFu" value="����"><br></td>
 <td colspan="3">
 <div align="center">
 </div>
 </td>
 </tr>
 <tr>
 <td height="113">
 <div align="center">
 ��ע
 </div>
 </td>
 <td colspan="5"><textarea title="��ע" inputtype="AIOTextarea" readonly="readonly" fname="BZhu" style="width: 700px; height: 100px;"></textarea><br></td>
 </tr>
 <tr>
 <td height="43">
 <p align="center">
 �ظ�ʱ��
 </p>
 </td>
 <td colspan="5"><input type="text" title="�ظ�ʱ��" inputtype="AIOText" fname="BTime" readonly="readonly"><br></td>
 </tr>
 <tr>
 <td height="43">
 <div align="center"><br></div>
 </td>
 <td colspan="5"><br></td>
 </tr>
 </tbody>
</table>','Normal','0','5','0','','CommonFunction','44d1f2b3_1312131340081260050','1','','0','','','1','0','0','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260054','44d1f2b3_1312131340081260049','checkPersons','0','0','0','0','0','0','','2','8000','0','100','0','','','0','','','0','','','','0','','','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260051','44d1f2b3_1312131340081260049','classCode','0','0','0','0','0','0','','2','500','0','100','0','','','0','','','0','','','','0','','','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081290093','44d1f2b3_1312131340081260049','id','0','0','1','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260052','44d1f2b3_1312131340081260049','workFlowNode','0','0','0','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260053','44d1f2b3_1312131340081260049','workFlowNodeName','0','0','0','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260055','44d1f2b3_1312131340081260049','DepartmentCode','1','1','0','0','0','0','@Sess:DepartmentCode;@Sess:DepartmentName','2','200','224','2','2','','OADepartment','0','','','0','','','','0','','44d1f2b3_1312131340081260056','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260057','44d1f2b3_1312131340081260049','EmployeeID','1','2','0','0','0','0','@Sess:UserId;@Sess:UserName','2','200','224','2','2','','OAEmployee','0','','','0','','','','0','','44d1f2b3_1312131340081260058','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081260059','44d1f2b3_1312131340081260049','duty','1','3','0','0','0','0','','2','80','224','1','1','duty','','0','','','0','','','','0','','44d1f2b3_1312131340081260060','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081270061','44d1f2b3_1312131340081260049','LeavebillType','1','4','0','0','0','0','','2','200','224','10','10','LeavebillType','','0','','','0','','','','0','','44d1f2b3_1312131340081270062','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081270063','44d1f2b3_1312131340081260049','due','1','5','0','0','0','0','','3','5000','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081270064','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081270065','44d1f2b3_1312131340081260049','STime','1','6','0','0','0','0','','6','0','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081270066','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081270067','44d1f2b3_1312131340081260049','LTime','1','7','0','0','0','0','','6','0','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081270068','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081270069','44d1f2b3_1312131340081260049','ATime','1','8','0','0','0','0','','2','200','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081270070','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280071','44d1f2b3_1312131340081260049','BTime','1','9','0','0','0','0','','6','0','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280072','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280073','44d1f2b3_1312131340081260049','PFu','1','10','0','0','0','0','','2','80','224','10','10','YesNo','','0','','','0','','','','0','','44d1f2b3_1312131340081280074','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280075','44d1f2b3_1312131340081260049','BZhu','1','11','0','0','0','0','','3','5000','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280076','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280077','44d1f2b3_1312131340081260049','FJian','1','36','0','0','0','0','','14','0','224','0','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280078','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280081','44d1f2b3_1312131340081260049','lastUpdateBy','0','100','0','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280082','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280085','44d1f2b3_1312131340081260049','lastUpdateTime','0','100','0','0','0','0','','6','19','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280086','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280089','44d1f2b3_1312131340081260049','SCompanyID','0','100','0','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280090','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280087','44d1f2b3_1312131340081260049','statusId','0','100','0','0','0','0','0','0','0','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280088','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280091','44d1f2b3_1312131340081260049','finishTime','0','100','0','0','0','0','','6','19','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280092','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280079','44d1f2b3_1312131340081260049','createBy','0','100','1','0','0','0','','2','30','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280080','','','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('44d1f2b3_1312131340081280083','44d1f2b3_1312131340081260049','createTime','0','100','0','0','0','0','','6','19','0','100','0','','','0','','','0','','','','0','','44d1f2b3_1312131340081280084','','','0','0')
insert into tblLanguage(zh_CN,id) values('��ٵ�','44d1f2b3_1312131340081260050')
insert into tblLanguage(zh_CN,id) values('����','44d1f2b3_1312131340081260056')
insert into tblLanguage(zh_CN,id) values('����','44d1f2b3_1312131340081260058')
insert into tblLanguage(zh_CN,id) values('ְ��','44d1f2b3_1312131340081260060')
insert into tblLanguage(zh_CN,id) values('������','44d1f2b3_1312131340081270062')
insert into tblLanguage(zh_CN,id) values('�������','44d1f2b3_1312131340081270064')
insert into tblLanguage(zh_CN,id) values('��ʼʱ��','44d1f2b3_1312131340081270066')
insert into tblLanguage(zh_CN,id) values('����ʱ��','44d1f2b3_1312131340081270068')
insert into tblLanguage(zh_CN,id) values('��Сʱ','44d1f2b3_1312131340081270070')
insert into tblLanguage(zh_CN,id) values('�ظ�ʱ��','44d1f2b3_1312131340081280072')
insert into tblLanguage(zh_CN,id) values('����','44d1f2b3_1312131340081280074')
insert into tblLanguage(zh_CN,id) values('��ע','44d1f2b3_1312131340081280076')
insert into tblLanguage(zh_CN,id) values('����','44d1f2b3_1312131340081280078')
insert into tblLanguage(zh_CN,id) values('����޸���','44d1f2b3_1312131340081280082')
insert into tblLanguage(zh_CN,id) values('�޸�ʱ��','44d1f2b3_1312131340081280086')
insert into tblLanguage(zh_CN,id) values('��֧����','44d1f2b3_1312131340081280090')
insert into tblLanguage(zh_CN,id) values('״̬','44d1f2b3_1312131340081280088')
insert into tblLanguage(zh_CN,id) values('����ʱ��','44d1f2b3_1312131340081280092')
insert into tblLanguage(zh_CN,id) values('������','44d1f2b3_1312131340081280080')
insert into tblLanguage(zh_CN,id) values('����ʱ��','44d1f2b3_1312131340081280084')

--2017-12-27 16:50:42�޸�ö��
delete from tblLanguage where id in (select languageId from tblDBEnumerationItem where enumId=(select id from tblDBEnumeration where enumName='duty'))
delete from tblLanguage where id in (select languageId from tblDBEnumeration where enumName='duty')
delete from tblDBEnumerationItem where enumId=(select id from tblDBEnumeration where enumName='duty');
delete from tblDBEnumeration where enumName='duty';
INSERT INTO [tblDBEnumeration]([createTime],[checkPersons],[printCount],[lastUpdateTime],[SCompanyID],[workFlowNodeName],[lastUpdateBy],[mainModule],[createBy],[languageId],[id],[RowON],[workFlowNode],[enumName],[classCode]) values('2008-12-09 22:02:45','','0','2017-09-30 09:14:36','','finish','1','0','d5d7c3e1_0811241513133280002','927f768c_1709300914364348054','4974bf46_0812092202451080470','                                                                                                    ','-1','duty','                                                                                                    ')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348055','','','0','0','','4974bf46_0812092202451080470','','','11','927f768c_1709300914364348056')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348057','','','0','1','','4974bf46_0812092202451080470','','','1','927f768c_1709300914364348058')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348059','','','0','2','','4974bf46_0812092202451080470','','','10','927f768c_1709300914364348060')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348061','','','0','2','','4974bf46_0812092202451080470','','','9','927f768c_1709300914364348062')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348063','','','0','3','','4974bf46_0812092202451080470','','','2','927f768c_1709300914364348064')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348065','','','0','4','','4974bf46_0812092202451080470','','','3','927f768c_1709300914364348066')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348067','','','0','5','','4974bf46_0812092202451080470','','','5','927f768c_1709300914364348068')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348069','','','0','6','','4974bf46_0812092202451080470','','','4','927f768c_1709300914364348070')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348071','','','0','7','','4974bf46_0812092202451080470','','','6','927f768c_1709300914364348072')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348073','','','0','8','','4974bf46_0812092202451080470','','','7','927f768c_1709300914364348074')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348075','','','0','9','','4974bf46_0812092202451080470','','','8','927f768c_1709300914364348076')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348077','','','0','20','','4974bf46_0812092202451080470','','','12','927f768c_1709300914364348078')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348079','','','0','100','','4974bf46_0812092202451080470','','','5136','927f768c_1709300914364348080')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348081','','','0','103','','4974bf46_0812092202451080470','','','15','927f768c_1709300914364348082')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348083','','','0','104','','4974bf46_0812092202451080470','','','14','927f768c_1709300914364348084')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348085','','','0','0','','4974bf46_0812092202451080470','','','16','927f768c_1709300914364348086')
INSERT INTO [tblDBEnumerationItem]([RowON],[id],[checkPersons],[workFlowNode],[printCount],[enumOrder],[SCompanyID],[enumId],[workFlowNodeName],[classCode],[enumValue],[languageId]) values('','927f768c_1709300914364348087','','','0','0','','4974bf46_0812092202451080470','','','17','927f768c_1709300914364348088')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348054','����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348056','ְԱ')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348058','����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348060','������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348062','���³�')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348064','�ܾ���')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348066','���ž���')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348068','���ܾ���')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348070','�鳤')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348072','������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348074','����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348076','������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348078','����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348080','�ϰ�')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348082','��Ʒ����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348084','�ܼ�')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348086','����')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('927f768c_1709300914364348088','���')
 --2017-12-27 16:50:42:�½�ģ��

 delete from tblLanguage where id in (select modelName from tblModules where tblName='OALeaveBill')
 delete tblModelOperations where f_ref in (select id from tblModules where tblName='OALeaveBill')
 delete tblModules where  tblName='OALeaveBill'
 declare @newCode varchar(50),@retCode varchar(50),@parentCode varchar(50) set @parentCode ='00112' 
 exec proc_getNewClassCode 'tblModules',@parentCode,@retCode output,@newCode output 
INSERT INTO [tblModules]([createTime],[linkAddress],[SystemParam],[checkPersons],[printCount],[lastUpdateTime],[SCompanyID],[IsHidden],[lastUpdateBy],[createBy],[statusId],[id],[RowON],[ICON],[tblName],[finishTime],[CheckPersont],[parentClass],[OrderBy],[workFlowNodeName],[IsUsed],[isDisplay],[modelName],[workFlowNode],[MainModule],[classCode],[isCatalog]) values('2012-02-23 11:01:27','/ReportDataAction.do?reportNumber=qjtjb','Normal','','0','2012-02-23 11:01:27','00001','2','7237978a_0912251620474210191','7237978a_0912251620474210191','0','4da282ae_1202231101271861474','','','OALeaveBill','2012-02-23 11:01:27','','','2000','finish','2','0','4da282ae_1202231101271531473','-1','2',@newCode,'0')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('4da282ae_1202231101271531473','���ͳ�Ʊ�')
INSERT INTO [tblModelOperations]([RowON],[moduleOpId],[OperationID],[workFlowNode],[SCompanyID],[workFlowNodeName],[classCode],[f_ref]) values('','1076','1','','00001','','','4da282ae_1202231101271861474')
INSERT INTO [tblModelOperations]([RowON],[moduleOpId],[OperationID],[workFlowNode],[SCompanyID],[workFlowNodeName],[classCode],[f_ref]) values('','1077','6','','00001','','','4da282ae_1202231101271861474')
 update tblModelOperations set moduleOpId=id where f_ref in (select id from tblModules where tblName='OALeaveBill') 
 --2017-12-27 16:50:42:�½�����

 delete tblReportsDet where f_ref in (select id from tblReports where reportNumber='OALeaveBill')
 delete from tblLanguage where id=(select ReportName from tblReports where reportNumber='OALeaveBill')
 delete from tblReports where  reportNumber='OALeaveBill'
 --2017-12-27 16:50:42:�½���ӡ����

 delete tblReportsDet where f_ref in (select id from tblReports where reportType='BILL' and billTable='OALeaveBill')
 delete from tblLanguage where id in(select ReportName from tblReports where reportType='BILL' and  billTable='OALeaveBill')
 delete from tblReports where reportType='BILL' and  billTable='OALeaveBill'
 --2017-12-27 16:50:42:�½�������

 delete from OAWorkFlowNodeApprover where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='OALeaveBill')) 
 delete from OAWorkFlowNodeConditionDet where conditionId in (select id from OAWorkFlowNodeCondition  where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='OALeaveBill'))) 
 delete from OAWorkFlowNodeCondition where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='OALeaveBill')) 
 delete from OAWorkFlowNodeField where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='OALeaveBill')) 
 delete from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='OALeaveBill') 
 delete OAWorkFlowTemplate  where  templateFile='OALeaveBill'
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','all','','0','','365bf9b7_1312271643502292724.xml','4','',',,,,00119,|,,,,|,,,,|,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="����֪��" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="294" top="83" code="1365471542397" id="1365471542397" allowCancel="true" to="1365471743864">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3832bdf5_0912211631568490003" userName="����Ȫ"/>
        <approve type="employee" typeName="ְԱ" user="7e9cda79_1209261757390380939" userName="��־��"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251628128400201" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251612007550187" userName="��СǮ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251449069600175" userName="��ѩ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251627060440199" userName="����ǿ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251620474210191" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="3832bdf5_0912211641050740584" userName="�鲨"/>
        <approve type="employee" typeName="ְԱ" user="c7cb000a_1003151018204879753" userName="����"/>
      </approvers>
      <fields>
        <field fieldName="PFu" notnull="true"/>
        <field fieldName="BTime" hidden="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="454" top="85" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="611" top="79" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="124" top="82" code="1388133903317" id="1388133903317" to="1365471542397"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471542397" to="1365471743864" fromCode="1365471542397" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="424" y3="99" length3="30" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="584" y3="89" length3="27" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="32" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471542397" fromCode="1388133903317" toCode="1365471542397" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="254" y3="97" length3="40" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2013-12-27 16:43:50','duty','5','','-1','365bf9b7_1312271643502292724','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','3832bdf5_0912211631568490003,7237978a_0912251620474210191,','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','3fcf7d04_1003220944281589905','0000200004','11','','1','','all','','0','','46a78652_1210151349025782027.xml','4','','','','','','','','2012-10-15 13:49:02','','3','','-1','46a78652_1210151349025782027','1','','','','0','','[�������],[�������],[�������],[����]','','87bae87d_1701051622476112354,','','','','4','cdcf7c24_1202201350433530631,','0','eae3edac_0906121936590150223','false','4','OALeaveBill','1','4','��ٵ�')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','67a08137_1605301426343371086','0000200001','3','','0','','','','0','','5b4834c4_1502051046244373380.xml','4','',',,|,,,,,,,,,,,|,,,,,,,,,,,|,,,,,,,,,,,,,,,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="279" top="84" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="433" top="82" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="120" top="82" code="1388133903317" id="1388133903317" to="1365471743864"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="409" y3="92" length3="24" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="28" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471743864" fromCode="1388133903317" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="250" y3="98" length3="29" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2015-02-05 10:46:24','duty','10','','0','5b4834c4_1502051046244373380','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','all','','0','','5c8627b4_1403051753103650091.xml','4','',',,,,,,00119,|,,,,,,|,,,,,,|,,,,,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="279" top="84" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="433" top="82" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="120" top="82" code="1388133903317" id="1388133903317" to="1365471743864"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="409" y3="92" length3="24" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="28" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471743864" fromCode="1388133903317" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="250" y3="98" length3="29" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2014-03-05 17:53:10','duty','7','','-1','5c8627b4_1403051753103650091','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','3832bdf5_0912211631568490003,','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','0ef3502a_1105071219215520280','0000200004','5','','1','','all','','0','','5fcf5f77_1304071406166069339.xml','','','','','','','','','2013-04-07 14:06:16','duty','','','-1','5fcf5f77_1304071406166069339','1','','','','0','','[����]����[�������]','','87bae87d_1701051622476112354,','','','4','4','','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','3fcf7d04_1003220944281589905','0000200004','5','','1','','all','','0','','5fcf5f77_1304090927277926103.xml','','','','','','','','','2013-04-09 09:27:27','duty','2','','-1','5fcf5f77_1304090927277926103','1','','','','0','','[����]����[�������]','','87bae87d_1701051622476112354,','','','','4','','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','4','��ٵ�')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','0ef3502a_1105071219215520280','0000200001','3','','1','','all','','0','','5fcf5f77_1304091008228756401.xml','4','','','','','','','','2013-04-09 10:08:22','duty','3','','-1','5fcf5f77_1304091008228756401','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','4','4','3832bdf5_0912211631568490003,','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','all','','0','','73eed876_1309241732076726431.xml','4','',',,00119,|,,|,,|,,,','','','','','','2013-09-24 17:32:07','duty','4','','-1','73eed876_1309241732076726431','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','3832bdf5_0912211631568490003,7237978a_0912251620474210191,','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','','','0','','811788d3_1410262215185254680.xml','4','',',,,,,,,,,00119,|,,,,,,,,,|,,,,,,,,,|,,,,,,,,,,,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="279" top="84" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="433" top="82" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="120" top="82" code="1388133903317" id="1388133903317" to="1365471743864"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="409" y3="92" length3="24" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="28" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471743864" fromCode="1388133903317" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="250" y3="98" length3="29" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2014-10-26 22:15:18','duty','9','','-1','811788d3_1410262215185254680','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200004','11','','1','','all','','0','','978c0b22_1204191406175403275.xml','4','','','','','','','','2012-04-19 14:06:17','','2','','-1','978c0b22_1204191406175403275','1','','','','0','','[�������],[�������],[�������],[����]','','87bae87d_1701051622476112354,','','','','4','cdcf7c24_1202201350433530631,','0','eae3edac_0906121936590150223','false','4','OALeaveBill','1','4','��ٵ�')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','all','','0','','ac3fda72_1312301129128332492.xml','4','',',,,,,,00119,|,,,,,,|,,,,,,|,,,,,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="����֪��" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="294" top="83" code="1365471542397" id="1365471542397" allowCancel="true" to="1365471743864">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3832bdf5_0912211631568490003" userName="����Ȫ"/>
        <approve type="employee" typeName="ְԱ" user="7e9cda79_1209261757390380939" userName="��־��"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251628128400201" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251612007550187" userName="��СǮ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251449069600175" userName="��ѩ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251627060440199" userName="����ǿ"/>
        <approve type="employee" typeName="ְԱ" user="7237978a_0912251620474210191" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="3832bdf5_0912211641050740584" userName="�鲨"/>
        <approve type="employee" typeName="ְԱ" user="c7cb000a_1003151018204879753" userName="����"/>
      </approvers>
      <fields>
        <field fieldName="PFu" notnull="true"/>
        <field fieldName="BTime" hidden="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="454" top="85" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="611" top="79" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="124" top="82" code="1388133903317" id="1388133903317" to="1365471542397"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471542397" to="1365471743864" fromCode="1365471542397" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="424" y3="99" length3="30" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="584" y3="89" length3="27" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="32" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471542397" fromCode="1388133903317" toCode="1365471542397" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="254" y3="97" length3="40" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2013-12-30 11:29:12','duty','6','','-1','ac3fda72_1312301129128332492','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','3832bdf5_0912211631568490003,','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','7237978a_0912251620474210191','0000200001','3','','0','','','','0','','b6b39b68_1404041215326631637.xml','4','',',,,,,,,,,00119,|,,,,,,,,,|,,,,,,,,,|,,,,,,,,,,,,,,,,,','','','','','<FlowNodes>
  <FlowNodes>
    <flowNode id="0" zAction="START" display="��ʼ" left="55" top="79" code="1365471501161" to="1388133903317">
      <fields>
        <field fieldName="BTime" hidden="true"/>
        <field fieldName="PFu" hidden="true"/>
        <field fieldName="BZhu" hidden="true"/>
        <field fieldName="LeavebillType" notnull="true"/>
        <field fieldName="STime" notnull="true"/>
        <field fieldName="LTime" notnull="true"/>
        <field fieldName="ATime" notnull="true"/>
      </fields>
    </flowNode>
    <flowNode zAction="CHECK" display="���º˶�����" allowBack="true" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="279" top="84" code="1365471743864" id="1365471743864" allowCancel="true" to="-1">
      <approvers>
        <approve type="employee" typeName="ְԱ" user="3fcf7d04_1003220944281589905" userName="������"/>
        <approve type="employee" typeName="ְԱ" user="46a78652_1210151108273941722" userName="��С��"/>
        <approve type="employee" typeName="ְԱ" user="c4d4f937_1306040845214426859" userName="������"/>
      </approvers>
    </flowNode>
    <flowNode id="-1" zAction="STOP" display="����" left="433" top="82" code="1365471838138"/>
    <flowNode zAction="CHECK" display="��������" allowBack="false" allowStop="false" allowJump="false" useAllApprove="false" timeLimit="" noteTime="" noteRate="" approvePeople="select" left="120" top="82" code="1388133903317" id="1388133903317" to="1365471743864"/>
  </FlowNodes>
  <Lines>
    <Line labelx="0" labely="0" from="1365471743864" to="-1" fromCode="1365471743864" toCode="1365471838138" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="409" y3="92" length3="24" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="0" to="1388133903317" fromCode="1365471501161" toCode="1388133903317" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="92" y3="89" length3="28" isvertical3="false" arrowType3="right"/>
    <Line labelx="0" labely="0" from="1388133903317" to="1365471743864" fromCode="1388133903317" toCode="1365471743864" x1="0" y1="0" length1="0" isvertical1="false" arrowType1="none" x2="0" y2="0" length2="0" isvertical2="false" arrowType2="none" x3="250" y3="98" length3="29" isvertical3="false" arrowType3="right"/>
  </Lines>
</FlowNodes>','2014-04-04 12:15:32','duty','8','','-1','b6b39b68_1404041215326631637','1','','','','0','','[����]����[�������]���[��ʼʱ��]��[����ʱ��]���','','87bae87d_1701051622476112354,','','','','4','','0','5fcf5f77_1304071406166069339','false','','OALeaveBill','1','','��ٵ�V1.0')
INSERT INTO [OAWorkFlowTemplate]([depMonitor],[detail],[designType],[stopStartWake],[timeType],[setWakeGroup],[usefulLifeS],[finishTime],[fileFinish],[stopSetWakeDept],[updateBy],[templateClass],[flowOrder],[stopSetWakeGroup],[allowAdd],[retdefineName],[defStatus],[setWakeDept],[depMonitorScope],[usefulLifeE],[workFlowFile],[setWake],[retCheckPerRule],[allowVisitor],[reviewWake],[applyLookFieldDisplay],[wakeUp],[stopSAllWake],[lines],[createTime],[fileContent],[version],[wakeLimitSQL],[statusId],[id],[templateType],[timeVal],[stopSetWakePer],[stopSetWake],[readLimit],[overTimeWake],[titleTemp],[affix],[perMonitor],[defineName],[parentTableName],[dispenseWake],[nextWake],[setWakePer],[perMonitorScope],[sameFlow],[autoPass],[allWake],[templateFile],[templateStatus],[startWake],[templateName]) values('','','','4','0','','','0','1','','','0000200004','11','','1','','all','','0','','eae3edac_0906121936590150223.xml','4','','','','','','','','2014-01-01 01-01-01','','1','','-1','eae3edac_0906121936590150223','1','','','','0','','[�������],[�������],[�������],[����]','','87bae87d_1701051622476112354,','','','','4','cdcf7c24_1202201350433530631,','0','eae3edac_0906121936590150223','false','4','OALeaveBill','1','4','��ٵ�')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','365bf9b7_1312271645471302781','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','365bf9b7_1312271643502292724','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','365bf9b7_1312271645471302789','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','365bf9b7_1312271643502292724','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','365bf9b7_1312271645471302791','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','365bf9b7_1312271643502292724','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471743864','0','0','0','0','','0','0.0','','','365bf9b7_1312271645471302792','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','select','0','','����֪��','0','','1','0','','','0','0.0','0','0','0','365bf9b7_1312271643502292724','1365471542397','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471542397','0','0','0','0','','0','0.0','','','365bf9b7_1312271645471302803','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','365bf9b7_1312271643502292724','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','8759bda3_1508240919254604631','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','5b4834c4_1502051046244373380','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471743864','0','0','0','0','','0','0.0','','','8759bda3_1508240919254604639','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','5b4834c4_1502051046244373380','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','8759bda3_1508240919254604641','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','5b4834c4_1502051046244373380','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','8759bda3_1508240919254604642','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','5b4834c4_1502051046244373380','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','5c8627b4_1403051753354390142','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','5c8627b4_1403051753103650091','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','5c8627b4_1403051753354400150','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','5c8627b4_1403051753103650091','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','5c8627b4_1403051753354410167','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','5c8627b4_1403051753103650091','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471743864','0','0','0','0','','0','0.0','','','5c8627b4_1403051753354410168','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','5c8627b4_1403051753103650091','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','1fed5dc5_1411030908059061544','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','811788d3_1410262215185254680','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471743864','0','0','0','0','','0','0.0','','','1fed5dc5_1411030908059061552','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','811788d3_1410262215185254680','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','1fed5dc5_1411030908059071555','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','811788d3_1410262215185254680','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','1fed5dc5_1411030908059071556','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','811788d3_1410262215185254680','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','ac3fda72_1312301129422312527','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','ac3fda72_1312301129128332492','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','ac3fda72_1312301129422312535','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','ac3fda72_1312301129128332492','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','ac3fda72_1312301129422322540','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','ac3fda72_1312301129128332492','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471542397','0','0','0','0','','0','0.0','','','ac3fda72_1312301129422322541','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','ac3fda72_1312301129128332492','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('1','1365471743864','0','0','0','0','','0','0.0','','','ac3fda72_1312301129422322546','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','select','0','','����֪��','0','','1','0','','','0','0.0','0','0','0','ac3fda72_1312301129128332492','1365471542397','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1388133903317','0','0','0','0','','0','0.0','','','b6b39b68_1404041215528141713','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','��ʼ','0','','0','0','','','0','0.0','0','0','0','b6b39b68_1404041215326631637','0','START')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','-1','0','0','0','0','','0','0.0','','','b6b39b68_1404041215528141721','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','���º˶�����','0','','1','0','','','0','0.0','0','0','0','b6b39b68_1404041215326631637','1365471743864','CHECK')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','','0','0','0','0','','0','0.0','','','b6b39b68_1404041215528161786','0.0','0','0','0','0','','0.0','0','0','0.0','0.0','0.0','0.0','0','0','0.0','','0','','����','0','','0','0','','','0','0.0','0','0','0','b6b39b68_1404041215326631637','-1','STOP')
INSERT INTO [OAWorkFlowNode]([allowJump],[to],[nextMail],[startMail],[nextSMS],[startSMS],[autoSelectPeopleSQL],[setMail],[rateMinute],[backExec],[passExec],[id],[noteRateUnit],[filterSet],[startMobile],[ideaRequired],[allSMS],[stopExec],[noteRate],[autoSelectPeople],[allowBack],[timeLimit],[noteTimeUnit],[awokeMinute],[limitMinute],[forwardTime],[allMail],[timeLimitUnit],[approvePeople],[setMobile],[conditionsId],[display],[allMobile],[fieldId],[allowCancel],[standaloneNoteSet],[approversId],[filterSetSQL],[nextMobile],[noteTime],[setSMS],[useAllApprove],[allowStop],[flowId],[keyId],[zAction]) values('0','1365471743864','0','0','0','0','','0','0.0','','','b6b39b68_1404041215528161787','0.0','0','0','0','0','','0.0','0','1','0.0','0.0','0.0','0.0','0','0','0.0','fix','0','','��������','0','','1','0','','','0','0.0','0','0','0','b6b39b68_1404041215326631637','1388133903317','CHECK')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302790','365bf9b7_1312271645471302789','��С��','employee','','46a78652_1210151108273941722')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302793','365bf9b7_1312271645471302792','����Ȫ','employee','','3832bdf5_0912211631568490003')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302794','365bf9b7_1312271645471302792','��־��','employee','','7e9cda79_1209261757390380939')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302795','365bf9b7_1312271645471302792','������','employee','','7237978a_0912251628128400201')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302796','365bf9b7_1312271645471302792','��СǮ','employee','','7237978a_0912251612007550187')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302797','365bf9b7_1312271645471302792','��ѩ','employee','','7237978a_0912251449069600175')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302798','365bf9b7_1312271645471302792','����ǿ','employee','','7237978a_0912251627060440199')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302799','365bf9b7_1312271645471302792','�鲨','employee','','3832bdf5_0912211641050740584')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302800','365bf9b7_1312271645471302792','����','employee','','c7cb000a_1003151018204879753')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','365bf9b7_1312271645471302804','365bf9b7_1312271645471302803','������','employee','','7237978a_0912251620474210191')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','8759bda3_1508240919254604640','8759bda3_1508240919254604639','��־��','employee','','1b8b569f_1505121700262621916')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','8759bda3_1508240919254604643','8759bda3_1508240919254604642','������','employee','','44937272_1406160912385807353')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','5c8627b4_1403051753354410166','5c8627b4_1403051753354400150','��С��','employee','','46a78652_1210151108273941722')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','5c8627b4_1403051753354420184','5c8627b4_1403051753354410168','������','employee','','7237978a_0912251620474210191')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','1fed5dc5_1411030908059061553','1fed5dc5_1411030908059061552','������','employee','','7237978a_0912251620474210191')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('����','1fed5dc5_1411030908059071554','1fed5dc5_1411030908059061552','�ܾ���','dept','','0011900001')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','1fed5dc5_1411030908059071557','1fed5dc5_1411030908059071556','������','employee','','44937272_1406160912385807353')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322539','ac3fda72_1312301129422312535','��С��','employee','','46a78652_1210151108273941722')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322545','ac3fda72_1312301129422322541','������','employee','','7237978a_0912251620474210191')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322547','ac3fda72_1312301129422322546','��ѩ','employee','','7237978a_0912251449069600175')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322548','ac3fda72_1312301129422322546','��СǮ','employee','','7237978a_0912251612007550187')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322549','ac3fda72_1312301129422322546','��־��','employee','','7e9cda79_1209261757390380939')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322550','ac3fda72_1312301129422322546','����','employee','','c7cb000a_1003151018204879753')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322551','ac3fda72_1312301129422322546','����ǿ','employee','','7237978a_0912251627060440199')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322552','ac3fda72_1312301129422322546','�鲨','employee','','3832bdf5_0912211641050740584')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322553','ac3fda72_1312301129422322546','����Ȫ','employee','','3832bdf5_0912211631568490003')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322554','ac3fda72_1312301129422322546','������','employee','','7237978a_0912251628128400201')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322555','ac3fda72_1312301129422322546','�࿡��','employee','','d7accd0a_1308230849586924619')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','ac3fda72_1312301129422322556','ac3fda72_1312301129422322546','������','employee','','7237978a_0912251620474210191')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('ְԱ','b6b39b68_1404041215528161785','b6b39b68_1404041215528141721','��С��','employee','','46a78652_1210151108273941722')
INSERT INTO [OAWorkFlowNodeApprover]([typeName],[id],[flowNodeId],[userName],[type],[checkType],[user]) values('����','b6b39b68_1404041215528161788','b6b39b68_1404041215528161787','�ܾ���','dept','','0011900001')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302782','0','','3','365bf9b7_1312271645471302781','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302783','0','','3','365bf9b7_1312271645471302781','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302784','0','','3','365bf9b7_1312271645471302781','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302785','1','','0','365bf9b7_1312271645471302781','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302786','1','','0','365bf9b7_1312271645471302781','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302787','1','','0','365bf9b7_1312271645471302781','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302788','1','','0','365bf9b7_1312271645471302781','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302801','1','','0','365bf9b7_1312271645471302792','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('365bf9b7_1312271645471302802','0','','3','365bf9b7_1312271645471302792','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604632','1','','0','8759bda3_1508240919254604631','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604633','0','','3','8759bda3_1508240919254604631','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604634','1','','0','8759bda3_1508240919254604631','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604635','1','','0','8759bda3_1508240919254604631','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604636','0','','3','8759bda3_1508240919254604631','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604637','1','','0','8759bda3_1508240919254604631','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('8759bda3_1508240919254604638','0','','3','8759bda3_1508240919254604631','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400143','1','','0','5c8627b4_1403051753354390142','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400144','0','','3','5c8627b4_1403051753354390142','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400145','1','','0','5c8627b4_1403051753354390142','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400146','1','','0','5c8627b4_1403051753354390142','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400147','1','','0','5c8627b4_1403051753354390142','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400148','0','','3','5c8627b4_1403051753354390142','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('5c8627b4_1403051753354400149','0','','3','5c8627b4_1403051753354390142','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061545','0','','3','1fed5dc5_1411030908059061544','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061546','0','','3','1fed5dc5_1411030908059061544','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061547','0','','3','1fed5dc5_1411030908059061544','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061548','1','','0','1fed5dc5_1411030908059061544','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061549','1','','0','1fed5dc5_1411030908059061544','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061550','1','','0','1fed5dc5_1411030908059061544','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('1fed5dc5_1411030908059061551','1','','0','1fed5dc5_1411030908059061544','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312528','1','','0','ac3fda72_1312301129422312527','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312529','0','','3','ac3fda72_1312301129422312527','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312530','1','','0','ac3fda72_1312301129422312527','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312531','0','','3','ac3fda72_1312301129422312527','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312532','0','','3','ac3fda72_1312301129422312527','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312533','1','','0','ac3fda72_1312301129422312527','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422312534','1','','0','ac3fda72_1312301129422312527','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422322557','0','','3','ac3fda72_1312301129422322546','BTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('ac3fda72_1312301129422322558','1','','0','ac3fda72_1312301129422322546','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141714','1','','0','b6b39b68_1404041215528141713','LTime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141715','1','','0','b6b39b68_1404041215528141713','LeavebillType')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141716','0','','3','b6b39b68_1404041215528141713','PFu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141717','1','','0','b6b39b68_1404041215528141713','STime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141718','0','','3','b6b39b68_1404041215528141713','BZhu')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141719','1','','0','b6b39b68_1404041215528141713','ATime')
INSERT INTO [OAWorkFlowNodeField]([id],[isNotNull],[fieldType],[inputType],[flowNodeId],[fieldName]) values('b6b39b68_1404041215528141720','0','','3','b6b39b68_1404041215528141713','BTime')