--2017-08-26 13:56:26:�½���
    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSubAccount]') AND type in (N'U'))
    begin
    delete from tblLanguage where id in (select f.languageId from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblSubAccount') 
    delete from tblLanguage where id in (select f.groupName from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblSubAccount')
    delete from tblLanguage where id in (select t.languageId from tblDBTableInfo t where t.tableName = 'tblSubAccount') 
    exec proc_deleteExistsTable @tableName='tblSubAccount'
    drop table tblSubAccount
    end
create table tblSubAccount ( zlBank varchar(100) null,f_ref varchar(30) null,id bigint not null IDENTITY (1, 1), subzlAccount varchar(100) null,subComFullName varchar(100) null,Manager varchar(100) null,Remarks varchar(2000) null)
CREATE CLUSTERED INDEX Inx_tblSubAccount_f_ref ON tblSubAccount(f_ref,id) 
 alter   table   tblSubAccount add   constraint   PK_tblSubAccount  primary   key   (id)
alter table tblSubAccount add constraint FK_f_ref_id170826135626284 foreign key (f_ref) references tblCompany ON DELETE CASCADE ON UPDATE CASCADE 
insert into tblDBTableInfo (id,tableName,tableType,perantTableName,udType,updateAble,createBy,createTime,lastUpdateBy,lastUpdateTime,fieldCalculate,approveFlow,approveField,defRowCount,isSunCmpShare,isBaseInfo,needsCopy,wakeUp,hasNext,isView,isNull,reAudit,isLayout,layoutHTML,tableSysType,classFlag,classCount,draftFlag,extendButton,sysParameter,languageId,triggerExpress,tableDesc,MainModule,relationTable,relationView,isUsed,tWidth,tHeight,brotherType,copyParent)
values('1a53670c_1708221348025210045','tblSubAccount','1','tblCompany;','0','0','1','2017-08-22 13:48:02','1','2017-08-22 15:00:00','',null,null,'1','0','0','0','0','0','0','0','0','0','','Normal','0','6','0','','CommonFunction','1a53670c_1708221348025210046','0','','0','','','1','0','0','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025220048','1a53670c_1708221348025210045','zlBank','0','0','0','0','0','0','','2','100','100','1','1','zlBank','','0','','','0','','','','0','','1a53670c_1708221348025220049',null,'','0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025210047','1a53670c_1708221348025210045','f_ref','0','0','0','0','0','0',null,'2','30','0','0','0',null,null,'0',null,null,'0',null,null,null,'0',null,null,null,null,'0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025240063','1a53670c_1708221348025210045','id','0','0','1','0','0','0',null,'0','30','0','100','0',null,null,'0',null,null,'0',null,null,null,'0',null,null,null,null,'0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025220051','1a53670c_1708221348025210045','subzlAccount','1','1','0','0','0','0','','2','100','150','0','0','','','0','','','0','','','','0','','1a53670c_1708221348025220052',null,'','0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025220054','1a53670c_1708221348025210045','subComFullName','1','2','0','0','0','0','','2','100','150','0','0','','','0','','','0','','','','0','','1a53670c_1708221348025220055',null,'','0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025220057','1a53670c_1708221348025210045','Manager','1','3','0','0','0','0','','2','100','100','0','0','','','0','','','0','','','','0','','1a53670c_1708221348025220058',null,'','0','2')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('1a53670c_1708221348025220060','1a53670c_1708221348025210045','Remarks','1','4','0','0','0','0','','2','2000','200','0','0','','','0','','','0','','','','0','','1a53670c_1708221348025220061',null,'','0','2')
insert into tblLanguage(zh_CN,id) values('���˻���ϸ��','1a53670c_1708221348025210046')
insert into tblLanguage(zh_CN,id) values('����ֱ������','1a53670c_1708221348025220049')
insert into tblLanguage(zh_CN,id) values('����ֱ�����˺�','1a53670c_1708221348025220052')
insert into tblLanguage(zh_CN,id) values('�ӹ�˾����','1a53670c_1708221348025220055')
insert into tblLanguage(zh_CN,id) values('������','1a53670c_1708221348025220058')
insert into tblLanguage(zh_CN,id) values('��ע','1a53670c_1708221348025220061')

--2017-08-26 13:56:26�޸�ö��
delete from tblLanguage where id in (select languageId from tblDBEnumerationItem where enumId=(select id from tblDBEnumeration where enumName='zlBank'))
delete from tblLanguage where id in (select languageId from tblDBEnumeration where enumName='zlBank')
delete from tblDBEnumerationItem where enumId=(select id from tblDBEnumeration where enumName='zlBank');
delete from tblDBEnumeration where enumName='zlBank';
INSERT INTO [tblDBEnumeration]([classCode],[checkPersons],[languageId],[mainModule],[SCompanyID],[RowON],[createBy],[createTime],[printCount],[workFlowNode],[id],[workFlowNodeName],[enumName],[lastUpdateBy],[lastUpdateTime]) values('                                                                                                    ','','1a53670c_1708221459226310289','0','','                                                                                                    ','1','2016-09-21 10:56:59','0','','980e7065_1609211056598200026','','zlBank','1','2017-08-22 14:59:22')
INSERT INTO [tblDBEnumerationItem]([classCode],[enumId],[enumValue],[checkPersons],[enumOrder],[printCount],[languageId],[workFlowNode],[id],[workFlowNodeName],[SCompanyID],[RowON]) values('','980e7065_1609211056598200026','jsyh','','0','0','1a53670c_1708221459226310291','','1a53670c_1708221459226310290','','','')
INSERT INTO [tblDBEnumerationItem]([classCode],[enumId],[enumValue],[checkPersons],[enumOrder],[printCount],[languageId],[workFlowNode],[id],[workFlowNodeName],[SCompanyID],[RowON]) values('','980e7065_1609211056598200026','zsyh','','1','0','1a53670c_1708221459226310293','','1a53670c_1708221459226310292','','','')
INSERT INTO [tblDBEnumerationItem]([classCode],[enumId],[enumValue],[checkPersons],[enumOrder],[printCount],[languageId],[workFlowNode],[id],[workFlowNodeName],[SCompanyID],[RowON]) values('','980e7065_1609211056598200026','dgyh','','5','0','1a53670c_1708221459226310295','','1a53670c_1708221459226310294','','','')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('1a53670c_1708221459226310289','����ֱ������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('1a53670c_1708221459226310291','��������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('1a53670c_1708221459226310293','��������')
INSERT INTO [tblLanguage]([id],[zh_CN]) values('1a53670c_1708221459226310295','��ݸ����')
 --2017-08-26 13:56:26:�½�ģ��

 delete from tblLanguage where id in (select modelName from tblModules where tblName='tblSubAccount')
 delete tblModelOperations where f_ref in (select id from tblModules where tblName='tblSubAccount')
 delete tblModules where  tblName='tblSubAccount'
 declare @newCode varchar(50),@retCode varchar(50),@parentCode varchar(50) set @parentCode ='' 
 exec proc_getNewClassCode 'tblModules',@parentCode,@retCode output,@newCode output 
 update tblModelOperations set moduleOpId=id where f_ref in (select id from tblModules where tblName='tblSubAccount') 
 --2017-08-26 13:56:26:�½�����

 delete tblReportsDet where f_ref in (select id from tblReports where reportNumber='tblSubAccount')
 delete from tblLanguage where id=(select ReportName from tblReports where reportNumber='tblSubAccount')
 delete from tblReports where  reportNumber='tblSubAccount'
 --2017-08-26 13:56:26:�½���ӡ����

 delete tblReportsDet where f_ref in (select id from tblReports where reportType='BILL' and billTable='tblSubAccount')
 delete from tblLanguage where id in(select ReportName from tblReports where reportType='BILL' and  billTable='tblSubAccount')
 delete from tblReports where reportType='BILL' and  billTable='tblSubAccount'
 --2017-08-26 13:56:26:�½�������

 delete from OAWorkFlowNodeApprover where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSubAccount')) 
 delete from OAWorkFlowNodeConditionDet where conditionId in (select id from OAWorkFlowNodeCondition  where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSubAccount'))) 
 delete from OAWorkFlowNodeCondition where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSubAccount')) 
 delete from OAWorkFlowNodeField where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSubAccount')) 
 delete from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblSubAccount') 
 delete OAWorkFlowTemplate  where  templateFile='tblSubAccount'