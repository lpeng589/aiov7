--2017-12-27 16:22:18:�½���
    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblexpenseaccountDet]') AND type in (N'U'))
    begin
    delete from tblLanguage where id in (select f.languageId from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblexpenseaccountDet') 
    delete from tblLanguage where id in (select f.groupName from tblDBFieldInfo f,tblDBTableInfo t where f.tableId = t.id and t.tableName = 'tblexpenseaccountDet')
    delete from tblLanguage where id in (select t.languageId from tblDBTableInfo t where t.tableName = 'tblexpenseaccountDet') 
    exec proc_deleteExistsTable @tableName='tblexpenseaccountDet'
    drop table tblexpenseaccountDet
    end
create table tblexpenseaccountDet ( f_ref varchar(30) null,id varchar(30) not null, workFlowNode varchar(30) null,workFlowNodeName varchar(30) null,checkPersons varchar(8000) null,detOrderNo bigint not null IDENTITY (1, 1), EmployeeCode varchar(100) not null,Business numeric(18, 8) not null)
CREATE CLUSTERED INDEX Inx_tblexpenseaccountDet_f_ref ON tblexpenseaccountDet(f_ref,id) 
 alter   table   tblexpenseaccountDet add   constraint   PK_tblexpenseaccountDet  primary   key   (id)
alter table tblexpenseaccountDet add constraint FK_f_ref_id171227162218037 foreign key (f_ref) references tblexpenseaccount ON DELETE CASCADE ON UPDATE CASCADE 
insert into tblDBTableInfo (id,tableName,tableType,perantTableName,udType,updateAble,createBy,createTime,lastUpdateBy,lastUpdateTime,fieldCalculate,approveFlow,approveField,defRowCount,isSunCmpShare,isBaseInfo,needsCopy,wakeUp,hasNext,isView,isNull,reAudit,isLayout,layoutHTML,tableSysType,classFlag,classCount,draftFlag,extendButton,sysParameter,languageId,triggerExpress,tableDesc,MainModule,relationTable,relationView,isUsed,tWidth,tHeight,brotherType,copyParent)
values('16498250_1107301008153145731','tblexpenseaccountDet','1','tblexpenseaccount;','0','0','07a6a75b_1010190907332452623','2011-07-30 10:08:15','7237978a_0912251620474210191','2011-08-03 14:57:43','','',null,'4','0','0','0','0','0','0','0','0','0',null,'Normal','0','5','0','','CommonFunction','8cccd950_1108031457435081768','0','','0','','','1','0','0','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153145734','16498250_1107301008153145731','f_ref','1','0','0','0','0','0',null,'2','30','0','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153155748','16498250_1107301008153145731','id','1','0','1','0','0','0',null,'2','30','0','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153145735','16498250_1107301008153145731','workFlowNode','0','0','0','0','0','0',null,'2','30','0','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153145736','16498250_1107301008153145731','workFlowNodeName','0','0','0','0','0','0',null,'2','30','0','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153145737','16498250_1107301008153145731','checkPersons','0','0','0','0','0','0',null,'2','8000','0','100','0',null,null,'0',null,null,'0',null,null,null,'1',null,null,null,null,'0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153145733','16498250_1107301008153145731','detOrderNo','0','0','1','0','0','0','','0','0','0','100','100',null,null,'0','','','0','','',null,'1','','',null,'','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1107301008153155738','16498250_1107301008153145731','EmployeeCode','1','1','1','0','0','0','','2','100','350','0','0',null,null,'0','','','0','','',null,'1','','8cccd950_1108031457435091769',null,'','0','0')
insert into tblDBFieldInfo (id,tableId,fieldName,isCopy,listOrder,isNull,isReAudit,isUnique,isStat,defaultValue,fieldType,maxLength,width,inputType,inputTypeOld,refEnumerationName,inputValue,digits,calculate,logicValidate,udType,fieldSysType,fieldIdentityStr,copyType,statusId,popupType,languageId,groupName,insertTable,isLog,isMobile)
values('16498250_1108021943518742029','16498250_1107301008153145731','Business','1','2','1','0','0','1','','1','0','60','0','0',null,null,'2','{backBlance}=" ";if({originalBorrow}>=0.01){backBlance}=Number({originalBorrow})-Number(sum{tblexpenseaccountDet_Business});','','0','','',null,'1','','16498250_1108021847328941958',null,'','0','0')
insert into tblLanguage(zh_CN,id) values('���ñ�����ϸ','8cccd950_1108031457435081768')
insert into tblLanguage(zh_CN,id) values('��;','8cccd950_1108031457435091769')
insert into tblLanguage(zh_CN,id) values('���(Ԫ)','16498250_1108021847328941958')

 --2017-12-27 16:22:18:�½�ģ��

 delete from tblLanguage where id in (select modelName from tblModules where tblName='tblexpenseaccountDet')
 delete tblModelOperations where f_ref in (select id from tblModules where tblName='tblexpenseaccountDet')
 delete tblModules where  tblName='tblexpenseaccountDet'
 declare @newCode varchar(50),@retCode varchar(50),@parentCode varchar(50) set @parentCode ='' 
 exec proc_getNewClassCode 'tblModules',@parentCode,@retCode output,@newCode output 
 update tblModelOperations set moduleOpId=id where f_ref in (select id from tblModules where tblName='tblexpenseaccountDet') 
 --2017-12-27 16:22:18:�½�����

 delete tblReportsDet where f_ref in (select id from tblReports where reportNumber='tblexpenseaccountDet')
 delete from tblLanguage where id=(select ReportName from tblReports where reportNumber='tblexpenseaccountDet')
 delete from tblReports where  reportNumber='tblexpenseaccountDet'
 --2017-12-27 16:22:18:�½���ӡ����

 delete tblReportsDet where f_ref in (select id from tblReports where reportType='BILL' and billTable='tblexpenseaccountDet')
 delete from tblLanguage where id in(select ReportName from tblReports where reportType='BILL' and  billTable='tblexpenseaccountDet')
 delete from tblReports where reportType='BILL' and  billTable='tblexpenseaccountDet'
 --2017-12-27 16:22:18:�½�������

 delete from OAWorkFlowNodeApprover where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblexpenseaccountDet')) 
 delete from OAWorkFlowNodeConditionDet where conditionId in (select id from OAWorkFlowNodeCondition  where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblexpenseaccountDet'))) 
 delete from OAWorkFlowNodeCondition where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblexpenseaccountDet')) 
 delete from OAWorkFlowNodeField where flowNodeId in (select id from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblexpenseaccountDet')) 
 delete from OAWorkFlowNode where  flowId in (select id from OAWorkFlowTemplate where templateFile='tblexpenseaccountDet') 
 delete OAWorkFlowTemplate  where  templateFile='tblexpenseaccountDet'